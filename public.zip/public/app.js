const auth = firebase.auth();

const whenSignedIn = document.getElementById('whenSignedIn');
const whenSignedOut = document.getElementById('whenSignedOut');

const signInBtn = document.getElementById('signInBtn');
const signOutBtn = document.getElementById('signOutBtn');

const userGreeting = document.getElementById('userGreeting');
const userId = document.getElementById('userId');

const btn_2 = document.getElementsByClassName("btn-2");
const btn_3 = document.getElementsByClassName("btn-3");
const btn_4 = document.getElementsByClassName("btn-4");

// const sel = document.getElementById("select");
// const upl = document.getElementById("upload");
// const retrieve = document.getElementById("retrieve");
// const delet = document.getElementById("delete");

// const namebox = document.getElementById("namebox");
// const upProgress = document.getElementById("UpProgress");
// const myimg = document.getElementById("myimg");

const provider = new firebase.auth.GoogleAuthProvider();


signInBtn.onclick = () => auth.signInWithPopup(provider);

signOutBtn.onclick = () => auth.signOut();

//const crntUserId = "";

auth.onAuthStateChanged(user => {
    if (user) {
        //signed in
        whenSignedIn.hidden = false;
        whenSignedOut.hidden = true;
        userGreeting.innerHTML = `<h3>Hello ${user.displayName}!</h3>`;
        userId.innerHTML = `<p>User ID: ${user.uid}</p>`;
        var crntUserId = user.uid;
        localStorage.setItem("User", crntUserId);
        console.log(crntUserId)
    } else {
        //not signed in
        whenSignedIn.hidden = true;
        whenSignedOut.hidden = false;
        userGreeting.innerHTML = ``;
        userId.innerHTML = ``;
    }
});


// var db = firebase.firestore();
// var st = firebase.storage();


// let usersRef;
// let unsubscribe;
// let popDoc;

// auth.onAuthStateChanged(user => {

//     if (user) {
        
//         // var userCurrent = user;
//         // localStorage.setItem("User", userCurrent);

//         usersRef = db.collection('users')
        
//         var crntUser = usersRef.doc(`${user.uid}`)

//         crntUser.set({
//             name: user.displayName,
//             uid: user.uid
//         }).then(function() {
//             console.log("Saved");
//         }).catch((error) => {
//             console.error("Error writing document: ", error);
//         });

//         var usersDataRef = crntUser.collection('data')
        
//         //TEST FIREBASE FIRST

//         var ImgName, ImgUrl;
//         var files = [];
//         var reader;

//         sel.onclick = function(e){
//             var input = document.createElement('input');
//             input.type='file';

//             input.onchange = e => {
//                 files = e.target.files;
//                 reader = new FileReader();
//                 reader.onload = function(){
//                     myimg.src = reader.result;
//                 }
//                 reader.readAsDataURL(files[0]);
//             }
//             input.click();
//         }

//         upl.onclick = function(){
//             ImgName = namebox.value;
//             //`${user.uid}/${ImgName}.png`
//             //'Images/'+ImgName+".png"
//             var uploadTask = st.ref(`Images/${user.uid}/${ImgName}.png`).put(files[0]);

//             uploadTask.on('state_changed', function(snapshot){
//                 var progress = (snapshot.bytesTransferred / snapshot.totalBytes)*100;
//                 upProgress.innerHTML= 'Upload'+progress+'%';
//             },
//             //error handling
//             function(error){
//                 alert('error in saving the image');
//             },

//             //Submitting image link to database
//             function(){
//                 uploadTask.snapshot.ref.getDownloadURL().then(function(url){
//                     ImgUrl = url;
                    
//                     usersDataRef.doc(`${ImgName}`).set({
//                         Name: ImgName,
//                         Link: ImgUrl
//                     });
//                 alert('image added successfully');
//                 }
//             );
//         });
//         }

//         function removeData(inp) {
//             var docRef = usersDataRef.doc(`${inp}`);
//             docRef.get().then((doc) => {
//                 if (doc.exists) {
//                     console.log("Document Data: ", doc.data());
//                     docRef.delete().then(() => {
//                         console.log("Doc Deleted");
//                     }).catch((error) => {
//                         console.error("Error removing Doc", error);
//                     });
//                 } else {
//                     console.log("No Document to Delete");
//                 }
//             }).catch((error) => {
//                 console.log("Error getting document:", error);
//             });
//         }

//         function addData(inp) {
//             usersDataRef.doc(`${inp}`)
//                 .set({
//                     dataUid: user.uid,
//                     dataName: inp,
//                     dataTime: Date.now()
//             }).then(function() {
//                 console.log("Data Saved");
//             }).catch((error) => {
//                 console.error("Error writing data document: ", error);
//             });
//         }

//         unsubscribe = usersDataRef
//             .where('dataUid', '==', user.uid)
//             .onSnapshot(querySnapshot => {

//             const items = querySnapshot.docs.map(doc => {
//                 //a list of names of the stored data
//                 return `<li>${ doc.data().dataName }</li>`

//             });

//             var dataList = items.join('');
//             console.log(dataList);

//         });

//     } else {
//         unsubscribe && unsubscribe();
//     }
// });