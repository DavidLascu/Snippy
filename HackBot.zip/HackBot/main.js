const Discord = require('discord.js');
const client = new Discord.Client();


client.commands = new Discord.Collection();
client.events = new Discord.Collection();

const token = 'ODM3ODc0MjI4Mzc1NTg0Nzcw.YIy5Lg.BTM0MCehkNsyp2tp9ONRiRMZnrA';


['command_handler', 'event_handler'].forEach(handler =>{
    require(`./handlers/${handler}`)(client, Discord);
})


client.login(token);
