module.exports = () =>{
    console.log('Hackbot is online!');
}