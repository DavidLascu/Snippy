module.exports = {
    name: 'allassignments',
    description: "Returns an embed with all upcoming assignments",
    execute(client, message, args, Discord){
        var date1 = '2021-05-20';
        var date2 = '2021-06-01';
        var date3 = '2021-06-05';

        const newEmbed = new Discord.MessageEmbed()
       .setColor('#8DBCF4')
       .setTitle('All Upcoming Assignments')
       .setURL('https://fir-test1-6d174.web.app/')
       .setAuthor('Snippy', 'https://cdn.discordapp.com/attachments/837876503593222167/838350642618564618/Untitled-2.png', 'https://fir-test1-6d174.web.app/')
       .setDescription(`These are your next upcoming assignments`)
       .addField('Assignment 1 - Research Project','____________',false)
       .addFields(
            {name: 'Date Due', value: date1, inline: true},
            {name: 'Class', value: 'CS246', inline: true},
       )
       .addField('Assignment 2 - Resume','____________',false)
       .addFields(
            {name: 'Date Due', value: date2, inline: true},
            {name: 'Class', value: 'PD11', inline: true},
       )
       .addField('Assignment 3 - Bio Exam','____________',false)
       .addFields(
            {name: 'Date Due', value: date3, inline: true},
            {name: 'Class', value: 'BIO200', inline: true},
       )
       .attachFiles(['https://cdn.discordapp.com/attachments/837876503593222167/838518879306121216/Research-Project.png',
                     'https://cdn.discordapp.com/attachments/837876503593222167/838523148382765086/Resume-Rubric.png',
                     'https://cdn.discordapp.com/attachments/837876503593222167/838523392041943060/BIO-Chapter.pdf'])
       .setTimestamp()
       .setFooter('Hope you ace it!');

       message.channel.send(newEmbed);      
    }
}