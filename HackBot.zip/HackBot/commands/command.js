module.exports = {
    name: 'command',
    description: "This is an embedded command",
    execute(client, message, args, Discord){
       const newEmbed = new Discord.MessageEmbed()
       .setColor('#8DBCF4')
       .setTitle('Rules')
       .setURL('https://ruhacks.com/')
       .setDescription(`This is a test embed`)
       .addFields(
            {name: 'Author 1', value: 'David'},
            {name: 'Author 2', value: 'Martin'},
            {name: 'Author 3', value: 'Drew'},
            {name: 'Author 4', value: 'Rat'},
       )
       .setImage('https://cdn.discordapp.com/attachments/127551346047057920/837935710399889418/20210501_021707.jpg')
       .setFooter('Make sure to hate on fern');

       message.channel.send(newEmbed);   
    }

}