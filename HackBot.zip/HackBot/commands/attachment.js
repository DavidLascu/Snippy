module.exports = {
    name: 'attachment',
    description: "Sends a file attachment",
    execute(client, message, args, Discord){
        message.channel.send(new Discord.MessageAttachment('https://clips-media-assets2.twitch.tv/AT-cm%7C932232159-preview.jpg'));
    }
}