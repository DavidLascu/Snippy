module.exports = {
    name: 'nextdate',
    description: "Returns an embed with the next major due date and its rubric ",
    execute(client, message, args, Discord){
        var today = new Date();
        var date = '2021-05-20';

        const newEmbed = new Discord.MessageEmbed()
       .setColor('#8DBCF4')
       .setTitle('Next Due Date: Research Project - CS246')
       .setURL('https://fir-test1-6d174.web.app/')
       .setAuthor('Snippy', 'https://cdn.discordapp.com/attachments/837876503593222167/838350642618564618/Untitled-2.png', 'https://fir-test1-6d174.web.app/')
       .setDescription(`This is your next upcoming assignment`)
       .addFields(
            {name: 'Date Due', value: date},
            {name: 'Class', value: 'CS246'},
       )
       .setImage('https://cdn.discordapp.com/attachments/837876503593222167/838518879306121216/Research-Project.png')
       .setTimestamp()
       .setFooter('Hope you ace it!');

       message.channel.send(newEmbed);      
    }
}