module.exports = {
    name: 'ping',
    description: "This is a ping command",
    execute(client, message, args){
        message.channel.send(`I hope you ${args[0]}`);
    }
}